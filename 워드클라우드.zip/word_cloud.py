def make_wcld(keyword):
  #### analysis
  import pandas as pd
  import numpy as np
  from konlpy.tag import Hannanum
  from collections import Counter
  import re
  from stopwords import stopwords

  context = pd.read_csv('context_DB.csv')

  def extract(x, keyword, r):
    try:
      if x.index(keyword) < r and x.index(keyword) > len(x) - r:
        return x
      elif x.index(keyword) < r:
        return x[0 : x.index(keyword)+r]
      elif x.index(keyword) > len(x) - r:
        return x[x.index(keyword)-r : -1]
      else:
        return x[x.index(keyword)-r : x.index(keyword)+r]
    except:
      return extract_upper(x, keyword, r)

  def extract_upper(x, keyword, r):
    new_keyword = keyword.upper()
    try:
      if x.index(new_keyword) < r and x.index(new_keyword) > len(x) - r:
        return x
      elif x.index(new_keyword) < r:
        return x[0 : x.index(new_keyword)+r]
      elif x.index(new_keyword) > len(x) - r:
        return x[x.index(new_keyword)-r : -1]
      else:
        return x[x.index(new_keyword)-r : x.index(new_keyword)+r]
    except:
      return extract_lower(x, keyword, r)

  def extract_lower(x, keyword, r):
    keyword = keyword.lower()
    try:
      if x.index(keyword) < r and x.index(keyword) > len(x) - r:
        return x
      elif x.index(keyword) < r:
        return x[0 : x.index(keyword)+r]
      elif x.index(keyword) > len(x) - r:
        return x[x.index(keyword)-r : -1]
      else:
        return x[x.index(keyword)-r : x.index(keyword)+r]
    except:
      return ''

  word = re.compile(f'[가-힣ㄱ-ㅎㅏ-ㆌ{keyword}{keyword.upper()}{keyword.lower()}]+')
  context['내용'] = context['내용'].apply(lambda x: word.findall(str(x)))
  context['내용'] = context['내용'].apply(lambda x: ' '.join(extract(x, keyword, 10)))

  ###
  context['len'] = context['내용'].apply(len)
  context_lst = list(context['내용'][context['len'] > 1])

  ###
  han = Hannanum()
  sw_han = han.nouns(stopwords)
  # https://konlpy.org/ko/latest/api/konlpy.tag/#module-konlpy.tag._hannanum
  context['context_han'] = context['내용'].apply(lambda x : han.nouns(str(x)))
  word_lst = list()
  for lst in context['context_han']:
    for word in lst:
      if word not in sw_han and len(word) > 1 and word not in keyword:
          word_lst.append(word)

  count = Counter(word_lst)
  freq_datas = dict(count.most_common(n=100))

  #### Wordcloud
  import matplotlib.font_manager as fm
  import matplotlib.pyplot as plt
  from PIL import Image
  from wordcloud import WordCloud

  fontpath = 'CookieRun Bold.ttf'
  font = fm.FontProperties(fname=fontpath, size=9)
  plt.rc('font', family='CookieRunBold')

  mask = np.array(Image.open("mask.png"))

  wordcl = WordCloud(font_path = fontpath,
      width = 800,
      height = 800,
      background_color="white",
      mask = mask,
      min_font_size = 3
  )

  wordcl = wordcl.generate_from_frequencies(freq_datas)
  plt.figure(figsize=(20, 20))
  plt.imshow(wordcl, interpolation="bilinear")
  plt.axis("off")
  plt.savefig(f'wordcloud_{keyword}.jpg', dpi=1500)