from crawling import *
import pandas as pd
from word_cloud import make_wcld

keyword = 'mz세대'

n_db = naver_crawling(keyword)
pan_db = pan_crawling(keyword)
maily_db = maily_crawling(keyword)
youtube_db = youtube_crawling(keyword)
dc_db = dc_crawling(keyword)

context_db = pd.concat([n_db, pan_db, maily_db, youtube_db, dc_db])
trend_db = naver_search_trend(keyword)

context_db.to_csv('context_DB.csv', index=False)
trend_db.to_csv('trend_DB.csv', index=False)

make_wcld(keyword)